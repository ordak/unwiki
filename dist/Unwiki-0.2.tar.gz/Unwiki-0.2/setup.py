from setuptools import setup

setup(name='Unwiki',
      version='0.2',
      description='Python Distribution Utilities',
      author='ordak',
      url='https://github.com/ordak/unwiki',
      packages=['unwiki'],
     )